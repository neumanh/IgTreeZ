#!/usr/bin/python3

from enum import IntEnum, auto


class NumState:
    NEGATIVE = -1
    NATURAL = 0
    POSITIVE = 1


class MyColors(IntEnum):
    BLUE = auto()
    RED = auto()
    GREEN = auto()


class PortStatus:
    DISABLE = 'disable'
    ENABLE = 'enable'
    ACTIVE = 'active'


class MyElement:
    def __init__(self, num: int, color: MyColors, port_status: str):
        self.num = num
        self.color = color
        self.port_status = port_status

    def print(self):
        print(f'num: {self.num}, color: {self.color}, port_status: {self.port_status}')


if __name__ == '__main__':
    e = MyElement(NumState.NATURAL, MyColors.BLUE, PortStatus.DISABLE)
    e.print()

    e.color = MyColors.RED
    e.port_status = PortStatus.ACTIVE
    e.print()
